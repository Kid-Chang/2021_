
public class Main {

	public static void main(String[] args) {
		new MinesweeperFrame(new Minesweeper(16, 16, 40));
	}

}
