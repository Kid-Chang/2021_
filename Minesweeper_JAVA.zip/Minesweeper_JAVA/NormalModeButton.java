
public class NormalModeButton {

}
