
public class FlagModeButton {

}
