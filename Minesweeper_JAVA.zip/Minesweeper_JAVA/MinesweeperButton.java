import java.awt.event.*;
import javax.swing.JButton;

public class MinesweeperButton extends JButton implements ActionListener{
	
	private Minesweeper minesweeper;
	private MinesweeperFrame frame;
	private int row, col;
	private char status = 'h'; //h = hide, r = reveal, f = flag, l = locked, w = wrong flag
	private int button_info;
	
	public MinesweeperButton(Minesweeper m, MinesweeperFrame f, int r, int c, int p) {
		minesweeper = m;
		frame = f;
		row = r;
		col = c;
		button_info = p; // -1 = This space is a mine, 0~8 = The number of adjacent mines
		addActionListener(this);
	}
	
	public char getStatus() {
		return status;
	}
	
	public boolean isMine() {
		if (button_info == -1) 
			return true;
		return false;
	}
	
	public int getInfo() { 
		return button_info;
	}
	
	public void button_status_redefine() {
		if (status == 'h') {
			if (isMine()) {
				status = 'r';
			} else {
				status = 'l';
			}
		} else if (status == 'f' && !isMine()) {
			status = 'w';
		}
		
	}
	
	public void actionPerformed(ActionEvent e) {
		if (frame.getMode() == 'n') { //normal mode일 경우
			if (status == 'h') {
				if (isMine()) {
					frame.gameover(row, col);
				} else {
					status = 'r';
					
					if(button_info==0) {
						System.out.println("zero");
						
						frame.eightShow(row, col);
					}
					
				}
			}
		}
		//System.out.println("click");
		frame.update();
		
	}
	
	
	public void changeStatus() {
		status = 'r';

	}
	
	
	
}
